# V1 — Nettoyage technique

Conserve le contenu et l’apparence du site.

- Suppression des gestionnaires de date RP dupliqués dans `index.html`, `Archives.html`, `About.html`, `Lorraine.html`, `Bretagne.html` et `Carte.html`.
- Une seule source de vérité pour la date RP : `initDateRP()` dans `script.js`.
- Cache PWA versionné en `lecho-v2`.
- Précache élargi aux pages Bretagne/Lorraine et aux ressources locales principales.
- Aucun contenu éditorial supprimé.
